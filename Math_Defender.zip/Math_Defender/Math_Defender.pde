// ===================================================
// GAME: Math Defender  (Versi Upgrade untuk Anak SD)
// Framework: Processing (Java mode) - Processing 3 / 4
// ===================================================
// Fitur baru:
//  1. 10 level, naik level tiap 5 jawaban benar
//  2. Kecepatan jauh lebih pelan (dan naik bertahap)
//  3. Tampilan ceria: monster lucu, bintang, partikel, nyawa (hati), pujian
//  4. Tiap operasi punya warna sendiri  (+ hijau, - biru, x oranye, : ungu)
//  5. Pengaturan ukuran layar (menu atau tombol R)
//  6. Layar pembuka beranimasi
//  7. Tiap operasi punya gambar monster sendiri
//  8. Menu untuk memilih operasi (boleh lebih dari satu)
//
// Cara main: ketik jawaban lalu tekan ENTER untuk menembak monster.
// Simpan file ini di folder bernama "tugas_komputer_grafik".
// ===================================================

// ---------- KONSTANTA ----------
final int VW = 960;            // lebar kanvas virtual (semua gambar memakai ukuran ini)
final int VH = 600;            // tinggi kanvas virtual
final int[][] RES = { {800, 500}, {960, 600}, {1280, 800}, {1440, 900} };
final String[] RES_NAME = { "Kecil", "Normal", "Besar", "Jumbo" };

final int ST_INTRO = 0, ST_MENU = 1, ST_PLAY = 2, ST_PAUSE = 3, ST_OVER = 4;
final int MAX_LEVEL = 10;
final int CORRECT_PER_LEVEL = 5;
final int MAX_LIVES = 3;
final int BASE_H = 90;
final int BASE_TOP = VH - BASE_H;

final int WHITE = 0xFFFFFFFF;
final String[] OP_NAME = { "Tambah", "Kurang", "Kali", "Bagi" };
final String[] OP_EXAMPLE = { "3 + 4", "9 - 5", "6 x 7", "12 : 3" };
// warna tiap operasi: hijau, biru, oranye, ungu
final int[] OP_COL  = { 0xFF2ED573, 0xFF3D9BFF, 0xFFFF9F1C, 0xFFB06CFF };
final int[] OP_DARK = { 0xFF138A4B, 0xFF1B5FB8, 0xFFC45F00, 0xFF6A2FC0 };

// tema latar belakang (berganti tiap naik level)
final int[][] THEME = {
  { 0xFF1B1464, 0xFF6C5CE7 },
  { 0xFF0B3C5D, 0xFF2EC4B6 },
  { 0xFF3A0CA3, 0xFFF72585 },
  { 0xFF0F4C3A, 0xFF7BD389 },
  { 0xFF1D2B64, 0xFFF8A5C2 }
};
final String[] PRAISE = { "Hebat!", "Mantap!", "Keren!", "Pintar!", "Wow!", "Yeay!" };

// posisi tombol menu
final float CARD_Y = 225, CARD_W = 190, CARD_H = 230;
final float ALL_Y = 372, RES_Y = 455, START_Y = 535;

// ---------- VARIABEL GAME ----------
int gameState = ST_INTRO;
ArrayList<Enemy> enemies = new ArrayList<Enemy>();
ArrayList<Particle> particles = new ArrayList<Particle>();
ArrayList<Popup> popups = new ArrayList<Popup>();

boolean[] opOn = { true, true, true, true };   // operasi yang dipilih
String currentInput = "";
int score = 0, highScore = 0, level = 1, lives = MAX_LIVES;
int correctInLevel = 0, combo = 0;
float spawnTimer = 0;
float shake = 0;
int shotTimer = 0;
float shotX1, shotY1, shotX2, shotY2;
int levelBanner = 0;
boolean bannerBonus = false;
float aimAngle = -HALF_PI;
int resIndex = 1;
int introStart = 0;
int menuMsgTimer = 0;

PFont fontBold;
PGraphics bg;
float[] starX = new float[90];
float[] starY = new float[90];
float[] starP = new float[90];
float[] starS = new float[90];

// skala layar
float sc = 1, ox = 0, oy = 0;
float dt = 1;
int lastMs = 0;

// ---------------------------------------------------
// SETUP & DRAW
// ---------------------------------------------------

void settings() {
  size(VW, VH);
}

void setup() {
  frameRate(60);
  surface.setTitle("Math Defender - Petualangan Matematika");
  fontBold = createFont("Arial Rounded MT Bold", 64, true);
  textFont(fontBold);
  bg = createGraphics(VW, VH);
  makeBackground(0);
  for (int i = 0; i < starX.length; i++) {
    starX[i] = random(VW);
    starY[i] = random(VH);
    starP[i] = random(TWO_PI);
    starS[i] = random(0.5, 2);
  }
  introStart = frameCount;
  lastMs = millis();
}

void draw() {
  int now = millis();
  dt = constrain((now - lastMs) / 16.667, 0, 3);
  lastMs = now;

  // skala supaya gambar selalu pas dengan ukuran jendela
  sc = min(width / (float) VW, height / (float) VH);
  ox = (width - VW * sc) / 2;
  oy = (height - VH * sc) / 2;

  background(0);
  pushMatrix();
  translate(ox, oy);
  scale(sc);
  textFont(fontBold);
  textAlign(CENTER, CENTER);
  rectMode(CENTER);
  ellipseMode(CENTER);

  if (gameState == ST_INTRO) {
    drawIntro();
  } else if (gameState == ST_MENU) {
    drawMenu();
  } else if (gameState == ST_PLAY) {
    drawGame(true);
  } else if (gameState == ST_PAUSE) {
    drawGame(false);
    drawPauseOverlay();
  } else if (gameState == ST_OVER) {
    drawGameOver();
  }
  popMatrix();
}

// ---------------------------------------------------
// BACKGROUND & HELPER GAMBAR
// ---------------------------------------------------

void makeBackground(int t) {
  t = t % THEME.length;
  bg.beginDraw();
  for (int y = 0; y < VH; y++) {
    bg.stroke(lerpColor(THEME[t][0], THEME[t][1], y / (float) VH));
    bg.line(0, y, VW, y);
  }
  bg.noStroke();
  // bulan
  bg.fill(255, 255, 255, 50);
  bg.ellipse(150, 130, 120, 120);
  bg.fill(255, 255, 255, 35);
  bg.ellipse(130, 115, 30, 30);
  bg.ellipse(175, 150, 22, 22);
  // planet bercincin
  bg.fill(255, 200, 120, 110);
  bg.ellipse(810, 150, 100, 100);
  bg.noFill();
  bg.stroke(255, 255, 255, 110);
  bg.strokeWeight(6);
  bg.ellipse(810, 150, 180, 36);
  bg.endDraw();
}

void drawBackground() {
  imageMode(CORNER);
  image(bg, 0, 0);
  noStroke();
  for (int i = 0; i < starX.length; i++) {
    float a = 140 + 110 * sin(frameCount * 0.04 * starS[i] + starP[i]);
    fill(255, 255, 230, a);
    ellipse(starX[i], starY[i], 2 + starS[i] * 1.5, 2 + starS[i] * 1.5);
  }
}

float easeOutBack(float p) {
  p = constrain(p, 0, 1);
  float q = p - 1;
  return 1 + 2.7 * q * q * q + 1.7 * q * q;
}

// teks dengan bayangan
void label(String s, float x, float y, float size, int col) {
  textSize(size);
  fill(0, 0, 0, alpha(col) * 0.35);
  text(s, x + 2, y + 3);
  fill(col);
  text(s, x, y);
}

// teks biasa tanpa bayangan
void plain(String s, float x, float y, float size, int col) {
  textSize(size);
  fill(col);
  text(s, x, y);
}

boolean over(float x, float y, float w, float h) {
  float mxv = (mouseX - ox) / sc;
  float myv = (mouseY - oy) / sc;
  return abs(mxv - x) < w / 2 && abs(myv - y) < h / 2;
}

void drawButton(String s, float x, float y, float w, float h, int col, int txtCol, float tsize, boolean active) {
  boolean hov = over(x, y, w, h);
  float g = hov ? 1.05 : 1.0;
  noStroke();
  fill(0, 0, 0, 70);
  rect(x + 3, y + 5, w * g, h * g, h / 2);
  stroke(255);
  strokeWeight(active ? 5 : 2);
  fill(col);
  rect(x, y, w * g, h * g, h / 2);
  noStroke();
  plain(s, x, y - 2, tsize, txtCol);
}

void drawStar(float x, float y, float r1, float r2, int n) {
  beginShape();
  for (int i = 0; i < n * 2; i++) {
    float ang = i * PI / n - HALF_PI;
    float r = (i % 2 == 0) ? r2 : r1;
    vertex(x + cos(ang) * r, y + sin(ang) * r);
  }
  endShape(CLOSE);
}

void drawHeart(float x, float y, float s, boolean full) {
  pushMatrix();
  translate(x, y);
  scale(s / 30.0);
  stroke(255);
  strokeWeight(2);
  if (full) fill(255, 80, 100);
  else fill(90, 90, 120, 160);
  beginShape();
  vertex(0, 12);
  bezierVertex(-28, -6, -14, -26, 0, -10);
  bezierVertex(14, -26, 28, -6, 0, 12);
  endShape(CLOSE);
  popMatrix();
}

// simbol operasi digambar dengan bentuk (bukan huruf), jadi pasti terlihat jelas
void drawOpSymbol(int op, float x, float y, float sz, int col) {
  noStroke();
  fill(col);
  float t = sz * 0.22;
  float l = sz * 0.5;
  if (op == 0) {
    rect(x, y, l * 2, t, t / 2);
    rect(x, y, t, l * 2, t / 2);
  } else if (op == 1) {
    rect(x, y, l * 2, t, t / 2);
  } else if (op == 2) {
    pushMatrix();
    translate(x, y);
    rotate(QUARTER_PI);
    rect(0, 0, l * 2, t, t / 2);
    rect(0, 0, t, l * 2, t / 2);
    popMatrix();
  } else {
    rect(x, y, l * 2, t, t / 2);
    ellipse(x, y - sz * 0.38, t * 1.3, t * 1.3);
    ellipse(x, y + sz * 0.38, t * 1.3, t * 1.3);
  }
}

void drawBadge(int op, float x, float y, float r) {
  stroke(OP_COL[op]);
  strokeWeight(max(2, r * 0.22));
  fill(255);
  ellipse(x, y, r * 2, r * 2);
  drawOpSymbol(op, x, y, r * 1.15, OP_DARK[op]);
}

// Gambar monster untuk tiap operasi:
// 0 = slime hijau (tambah), 1 = hantu biru (kurang),
// 2 = monster berduri oranye (kali), 3 = UFO ungu (bagi)
void drawMonster(int op, float x, float y, float s, float t) {
  int c = OP_COL[op];
  int d = OP_DARK[op];
  pushMatrix();
  translate(x, y + sin(t) * 3 * s);
  scale(s);
  float eyeY = 0, eyeGap = 14, eyeR = 15;

  if (op == 0) {
    // slime + antena
    stroke(d);
    strokeWeight(3);
    line(-18, -28, -26, -50);
    line(18, -28, 26, -50);
    noStroke();
    fill(255, 225, 70);
    ellipse(-26, -52, 11, 11);
    ellipse(26, -52, 11, 11);
    stroke(255);
    strokeWeight(3);
    fill(c);
    ellipse(0, 0, 86, 70);
    noStroke();
    fill(d);
    ellipse(-22, 33, 24, 12);
    ellipse(22, 33, 24, 12);
    eyeY = -5;
  } else if (op == 1) {
    // hantu / ubur-ubur
    noStroke();
    for (int pass = 0; pass < 2; pass++) {
      float g = (pass == 0) ? 7 : 0;
      fill(pass == 0 ? 255 : c);
      arc(0, 0, 78 + g, 78 + g, PI, TWO_PI);
      rect(0, 16, 78 + g, 32);
      for (int k = -2; k <= 2; k++) ellipse(k * 16, 31, 19 + g, 19 + g);
    }
    eyeY = -6;
  } else if (op == 2) {
    // monster berduri
    noStroke();
    for (int pass = 0; pass < 2; pass++) {
      float g = (pass == 0) ? 6 : 0;
      fill(pass == 0 ? 255 : c);
      for (int k = 0; k < 8; k++) {
        float ang = k * TWO_PI / 8 + t * 0.15;
        float tipR = 48 + g;
        float baseR = 28;
        triangle(cos(ang - 0.28) * baseR, sin(ang - 0.28) * baseR,
                 cos(ang + 0.28) * baseR, sin(ang + 0.28) * baseR,
                 cos(ang) * tipR, sin(ang) * tipR);
      }
      ellipse(0, 0, 68 + g, 68 + g);
    }
    eyeY = -4;
  } else {
    // UFO
    noStroke();
    for (int pass = 0; pass < 2; pass++) {
      float g = (pass == 0) ? 6 : 0;
      fill(pass == 0 ? 255 : lerpColor(c, 0xFFFFFFFF, 0.55));
      arc(0, 4, 52 + g, 52 + g, PI, TWO_PI);
      fill(pass == 0 ? 255 : c);
      ellipse(0, 10, 96 + g, 34 + g);
    }
    fill(255, 235, 90);
    ellipse(-28, 12, 9, 9);
    ellipse(0, 16, 9, 9);
    ellipse(28, 12, 9, 9);
    eyeY = -11;
    eyeGap = 9;
    eyeR = 11;
  }

  // mata (berkedip sesekali)
  boolean blink = (frameCount + op * 37) % 150 < 6;
  noStroke();
  fill(255);
  ellipse(-eyeGap, eyeY, eyeR, blink ? 3 : eyeR * 1.2);
  ellipse(eyeGap, eyeY, eyeR, blink ? 3 : eyeR * 1.2);
  if (!blink) {
    fill(30, 30, 60);
    ellipse(-eyeGap, eyeY + 2, eyeR * 0.5, eyeR * 0.6);
    ellipse(eyeGap, eyeY + 2, eyeR * 0.5, eyeR * 0.6);
  }
  // mulut
  if (op == 0 || op == 2) {
    noFill();
    stroke(d);
    strokeWeight(3);
    arc(0, eyeY + 15, 24, 16, 0.15, PI - 0.15);
  } else if (op == 1) {
    noStroke();
    fill(d);
    ellipse(0, eyeY + 22, 12, 14);
  }
  // lencana simbol operasi
  drawBadge(op, 38, -32, 15);
  popMatrix();
}

void drawRocket(float x, float y, float s, float ang) {
  pushMatrix();
  translate(x, y);
  rotate(ang);
  scale(s);
  noStroke();
  float f = 22 + random(0, 14);
  fill(255, 120, 30);
  triangle(-9, 34, 9, 34, 0, 34 + f * 1.6);
  fill(255, 230, 80);
  triangle(-5, 34, 5, 34, 0, 34 + f);
  fill(255, 80, 100);
  triangle(-14, 10, -30, 40, -12, 34);
  triangle(14, 10, 30, 40, 12, 34);
  stroke(255);
  strokeWeight(2);
  fill(235, 240, 255);
  ellipse(0, 5, 38, 80);
  fill(255, 80, 100);
  noStroke();
  arc(0, -20, 38, 50, PI, TWO_PI);
  stroke(255);
  strokeWeight(2);
  fill(90, 200, 255);
  ellipse(0, 2, 16, 16);
  popMatrix();
}

// ---------------------------------------------------
// LAYAR PEMBUKA (INTRO)
// ---------------------------------------------------

void drawIntro() {
  drawBackground();
  float t = frameCount - introStart;

  // roket lewat di atas
  float rx = (t * 3.2) % (VW + 400) - 200;
  drawRocket(rx, 70 + sin(t * 0.05) * 15, 0.8, HALF_PI - 0.15);

  // judul huruf demi huruf, melompat-lompat
  String title = "MATH DEFENDER";
  textSize(80);
  float total = 0;
  for (int i = 0; i < title.length(); i++) total += textWidth(title.charAt(i)) + 3;
  float xx = VW / 2.0 - total / 2;
  for (int i = 0; i < title.length(); i++) {
    char ch = title.charAt(i);
    float w = textWidth(ch) + 3;
    float p = constrain((t - i * 4) / 18.0, 0, 1);
    if (p > 0 && ch != ' ') {
      float s = easeOutBack(p);
      float yy = 185 + sin(t * 0.08 + i * 0.5) * 9;
      pushMatrix();
      translate(xx + w / 2, yy);
      scale(s);
      textSize(80);
      fill(0, 0, 0, 90);
      text(ch, 3, 5);
      fill(170 + 85 * sin(i * 0.5 + t * 0.03),
           170 + 85 * sin(i * 0.5 + 2 + t * 0.03),
           170 + 85 * sin(i * 0.5 + 4 + t * 0.03));
      text(ch, 0, 0);
      popMatrix();
    }
    xx += w;
  }

  if (t > 70) {
    float a = constrain((t - 70) * 6, 0, 255);
    label("Petualangan Matematika di Luar Angkasa", VW / 2, 262, 26, color(255, 240, 160, a));
  }

  // keempat monster muncul satu per satu
  for (int i = 0; i < 4; i++) {
    float p = constrain((t - 95 - i * 14) / 20.0, 0, 1);
    if (p <= 0) continue;
    float x = VW / 2 + (i - 1.5) * 185;
    drawMonster(i, x, 385, 1.15 * easeOutBack(p), t * 0.08 + i);
    if (p >= 1) label(OP_NAME[i], x, 470, 24, OP_COL[i]);
  }

  if (t > 160) {
    float pulse = 1 + 0.04 * sin(t * 0.12);
    drawButton("Tekan ENTER atau klik untuk mulai!", VW / 2, 540, 480 * pulse, 56 * pulse,
               0xFFFFE066, 0xFF5A3A00, 24, true);
  }
}

// ---------------------------------------------------
// MENU PILIH OPERASI & UKURAN LAYAR
// ---------------------------------------------------

float cardX(int i) { return VW / 2.0 + (i - 1.5) * 215; }
float resX(int i) { return VW / 2.0 + (i - 1.5) * 195; }

int countOn() {
  int n = 0;
  for (int i = 0; i < 4; i++) if (opOn[i]) n++;
  return n;
}

void drawMenu() {
  drawBackground();
  label("PILIH OPERASI HITUNG", VW / 2, 45, 40, WHITE);
  if (menuMsgTimer > 0) {
    menuMsgTimer--;
    label("Pilih minimal satu operasi ya!", VW / 2, 84, 20, 0xFFFF8A8A);
  } else {
    label("Jawab " + CORRECT_PER_LEVEL + " soal benar untuk naik level (ada " + MAX_LEVEL + " level)!",
          VW / 2, 84, 20, 0xFFFFF3B0);
  }

  drawButton("< AWAL", 82, 40, 120, 38, 0xFFE8ECFF, 0xFF3A3F66, 16, false);
  for (int i = 0; i < 4; i++) drawOpCard(i);

  boolean allOn = countOn() == 4;
  drawButton("PILIH SEMUA (CAMPUR)", VW / 2, ALL_Y, 270, 42,
             allOn ? 0xFFFFE066 : 0xFFE8ECFF, 0xFF3A3F66, 18, allOn);

  label("Ukuran Layar", VW / 2, 418, 20, 0xFFFFF3B0);
  for (int i = 0; i < RES.length; i++) {
    boolean cur = (i == resIndex);
    drawButton(RES_NAME[i] + " " + RES[i][0] + "x" + RES[i][1], resX(i), RES_Y, 185, 38,
               cur ? 0xFF2ED573 : 0xFFE8ECFF, cur ? WHITE : 0xFF3A3F66, 16, cur);
  }

  drawButton("MULAI MAIN!", VW / 2, START_Y, 320, 58, 0xFFFF6B9D, WHITE, 30, true);
  label("1-4: pilih operasi   |   A: semua   |   R: ukuran layar   |   B: layar awal   |   ENTER: mulai",
        VW / 2, 580, 15, 0xFFDDE3FF);
}

void drawOpCard(int i) {
  float x = cardX(i);
  float y = CARD_Y;
  boolean on = opOn[i];
  boolean hov = over(x, y, CARD_W, CARD_H);

  noStroke();
  fill(0, 0, 0, 80);
  rect(x + 4, y + 7, CARD_W, CARD_H, 24);
  stroke(on ? OP_COL[i] : 0xFF8890A8);
  strokeWeight(hov ? 8 : (on ? 6 : 3));
  fill(255, on ? 245 : 200);
  rect(x, y, CARD_W, CARD_H, 24);

  drawMonster(i, x, y - 50, 1.0, frameCount * 0.07 + i);

  if (!on) {
    noStroke();
    fill(30, 30, 60, 120);
    rect(x, y, CARD_W, CARD_H, 24);
  }

  noStroke();
  plain(OP_NAME[i], x, y + 36, 28, OP_DARK[i]);
  plain(OP_EXAMPLE[i], x, y + 70, 20, 0xFF555A70);

  stroke(255);
  strokeWeight(2);
  fill(on ? OP_COL[i] : 0xFF9AA0B8);
  rect(x, y + 100, 130, 30, 15);
  noStroke();
  plain((on ? "AKTIF" : "MATI") + "  [" + (i + 1) + "]", x, y + 99, 16, WHITE);
}

void toggleOp(int i) {
  if (opOn[i] && countOn() == 1) {
    menuMsgTimer = 90;
    return;
  }
  opOn[i] = !opOn[i];
}

void setAllOps() {
  for (int i = 0; i < 4; i++) opOn[i] = true;
}

void setRes(int i) {
  resIndex = (i + RES.length) % RES.length;
  surface.setSize(RES[resIndex][0], RES[resIndex][1]);
}

// ---------------------------------------------------
// LOGIKA GAME
// ---------------------------------------------------

float spawnInterval() {
  return max(2600, 5200 - (level - 1) * 260);   // milidetik
}

float baseSpeed() {
  return 0.38 + 0.035 * (level - 1);            // piksel per frame (pelan)
}

int maxEnemies() {
  return min(5, 3 + level / 4);
}

void startGame() {
  enemies.clear();
  particles.clear();
  popups.clear();
  score = 0;
  level = 1;
  lives = MAX_LIVES;
  correctInLevel = 0;
  combo = 0;
  currentInput = "";
  shake = 0;
  shotTimer = 0;
  levelBanner = 0;
  aimAngle = -HALF_PI;
  spawnTimer = spawnInterval() - 1200;   // musuh pertama muncul sekitar 1 detik
  makeBackground(0);
  gameState = ST_PLAY;
}

void gameOver() {
  highScore = max(highScore, score);
  currentInput = "";
  gameState = ST_OVER;
}

Enemy lowestEnemy() {
  Enemy best = null;
  for (Enemy e : enemies) {
    if (best == null || e.y > best.y) best = e;
  }
  return best;
}

boolean answerUsed(int ans) {
  for (Enemy e : enemies) if (e.answer == ans) return true;
  return false;
}

int pickOp() {
  int[] act = new int[4];
  int n = 0;
  for (int i = 0; i < 4; i++) if (opOn[i]) act[n++] = i;
  if (n == 0) return 0;
  return act[(int) random(n)];
}

float pickX() {
  float x = random(90, VW - 90);
  for (int tries = 0; tries < 12; tries++) {
    x = random(90, VW - 90);
    boolean ok = true;
    for (Enemy e : enemies) {
      if (e.y < 150 && abs(e.x - x) < 150) ok = false;
    }
    if (ok) break;
  }
  return x;
}

void explode(float x, float y, int col, int n) {
  for (int i = 0; i < n; i++) {
    float ang = random(TWO_PI);
    float sp = random(1.5, 6);
    int c = (i % 3 == 0) ? 0xFFFFE066 : ((i % 3 == 1) ? col : WHITE);
    particles.add(new Particle(x, y, cos(ang) * sp, sin(ang) * sp, random(30, 60), c,
                               random(6, 14), i % 2 == 0));
  }
}

void levelUp() {
  level++;
  correctInLevel = 0;
  bannerBonus = false;
  if (lives < MAX_LIVES) {
    lives++;
    bannerBonus = true;
  }
  levelBanner = 150;
  makeBackground(level - 1);
  spawnTimer = 0;
  for (int i = 0; i < 70; i++) {
    float ang = random(TWO_PI);
    float sp = random(2, 8);
    int[] cols = { 0xFFFFE066, 0xFFFF6B9D, 0xFF2ED573, 0xFF3D9BFF, 0xFFFF9F1C, 0xFFB06CFF };
    particles.add(new Particle(VW / 2, VH / 2 - 70, cos(ang) * sp, sin(ang) * sp - 2, random(50, 90),
                               cols[i % cols.length], random(8, 16), i % 2 == 0));
  }
}

void checkAnswer() {
  if (currentInput.length() == 0) return;
  int ans = Integer.parseInt(currentInput);

  // tembak monster yang cocok dan posisinya paling bawah (paling berbahaya)
  Enemy target = null;
  for (Enemy e : enemies) {
    if (e.answer == ans && (target == null || e.y > target.y)) target = e;
  }

  if (target != null) {
    combo++;
    int pts = 10 + min(combo - 1, 5) * 2;
    score += pts;
    aimAngle = atan2(target.y - BASE_TOP, target.x - VW / 2.0);
    shotX1 = VW / 2.0 + cos(aimAngle) * 96;
    shotY1 = BASE_TOP + sin(aimAngle) * 96;
    shotX2 = target.x;
    shotY2 = target.y;
    shotTimer = 8;
    explode(target.x, target.y, OP_COL[target.op], 34);
    popups.add(new Popup("+" + pts, target.x, target.y - 30, 0xFFFFE066));
    String msg = (combo >= 3) ? "Beruntun x" + combo + "!" : PRAISE[(int) random(PRAISE.length)];
    popups.add(new Popup(msg, target.x, target.y + 8, WHITE));
    enemies.remove(target);

    correctInLevel++;
    if (level < MAX_LEVEL && correctInLevel >= CORRECT_PER_LEVEL) {
      levelUp();
    } else if (level == MAX_LEVEL) {
      correctInLevel = min(correctInLevel, CORRECT_PER_LEVEL);
    }
  } else {
    combo = 0;
    shake = 8;
    popups.add(new Popup("Coba lagi ya!", VW / 2.0, BASE_TOP - 80, 0xFFFF8A8A));
  }
  currentInput = "";
}

void updateGame() {
  // munculkan monster
  spawnTimer += dt * 16.667;
  if (spawnTimer >= spawnInterval()) {
    if (enemies.size() < maxEnemies()) {
      enemies.add(new Enemy());
      spawnTimer = 0;
    } else {
      spawnTimer = spawnInterval() - 500;   // penuh, coba lagi sebentar lagi
    }
  }

  // gerakkan monster, cek apakah menyentuh benteng
  for (int i = enemies.size() - 1; i >= 0; i--) {
    Enemy e = enemies.get(i);
    e.update();
    if (e.y + 78 >= BASE_TOP) {
      explode(e.x, BASE_TOP - 30, OP_COL[e.op], 26);
      popups.add(new Popup("Aduh!", e.x, BASE_TOP - 70, 0xFFFF6B6B));
      enemies.remove(i);
      lives--;
      combo = 0;
      shake = 14;
      if (lives <= 0) {
        gameOver();
        return;
      }
    }
  }

  for (int i = particles.size() - 1; i >= 0; i--) {
    Particle p = particles.get(i);
    p.update();
    if (p.dead()) particles.remove(i);
  }
  for (int i = popups.size() - 1; i >= 0; i--) {
    Popup p = popups.get(i);
    p.update();
    if (p.life <= 0) popups.remove(i);
  }

  shake *= 0.9;
  if (shotTimer > 0) shotTimer--;
  if (levelBanner > 0) levelBanner--;

  // meriam mengarah ke monster terbawah
  Enemy tgt = lowestEnemy();
  float want = -HALF_PI;
  if (tgt != null) {
    want = constrain(atan2(tgt.y - BASE_TOP, tgt.x - VW / 2.0), -PI + 0.35, -0.35);
  }
  aimAngle = lerp(aimAngle, want, 0.15);
}

// ---------------------------------------------------
// GAMBAR GAMEPLAY
// ---------------------------------------------------

void drawGame(boolean running) {
  if (running) updateGame();
  if (gameState == ST_OVER) {   // game over terjadi di frame ini
    drawGameOver();
    return;
  }

  pushMatrix();
  if (shake > 0.5) translate(random(-shake, shake), random(-shake, shake));
  drawBackground();
  for (Enemy e : enemies) e.display();
  drawShot();
  drawBase();
  for (Particle p : particles) p.display();
  for (Popup p : popups) p.display();
  popMatrix();

  drawHUD();
  if (levelBanner > 0) drawLevelBanner();
}

void drawShot() {
  if (shotTimer <= 0) return;
  float a = shotTimer / 8.0;
  strokeCap(ROUND);
  stroke(255, 220, 90, 255 * a);
  strokeWeight(10 * a + 2);
  line(shotX1, shotY1, shotX2, shotY2);
  stroke(255, 255, 255, 255 * a);
  strokeWeight(3);
  line(shotX1, shotY1, shotX2, shotY2);
}

void drawBase() {
  // laras meriam (berputar)
  pushMatrix();
  translate(VW / 2.0, BASE_TOP + 2);
  rotate(aimAngle + HALF_PI);
  stroke(90, 120, 220);
  strokeWeight(3);
  fill(235, 240, 255);
  rect(0, -48, 24, 84, 8);
  fill(255, 200, 60);
  rect(0, -92, 34, 14, 6);
  popMatrix();

  // panel bawah
  noStroke();
  fill(25, 28, 75, 240);
  rect(VW / 2.0, VH - BASE_H / 2.0, VW, BASE_H);
  stroke(80, 220, 255);
  strokeWeight(4);
  line(0, BASE_TOP, VW, BASE_TOP);

  // kubah meriam
  stroke(255);
  strokeWeight(3);
  fill(90, 120, 220);
  arc(VW / 2.0, BASE_TOP + 2, 84, 84, PI, TWO_PI);
  noStroke();
  fill(255, 255, 255, 90);
  ellipse(VW / 2.0 - 14, BASE_TOP - 20, 16, 10);

  // kotak jawaban
  stroke(80, 220, 255);
  strokeWeight(4);
  fill(255);
  rect(VW / 2.0, VH - 36, 300, 50, 16);
  noStroke();
  if (currentInput.length() == 0) {
    plain("ketik jawaban...", VW / 2.0, VH - 38, 20, 0xFF9AA0B8);
  } else {
    String cur = ((frameCount / 25) % 2 == 0) ? "_" : " ";
    plain(currentInput + cur, VW / 2.0, VH - 38, 34, 0xFF2D3166);
  }
  plain("Ketik jawaban,", 150, VH - 48, 17, 0xFFDDE3FF);
  plain("lalu tekan ENTER", 150, VH - 26, 17, 0xFFDDE3FF);
  plain("P = jeda", VW - 120, VH - 48, 17, 0xFFDDE3FF);
  plain("Backspace = hapus", VW - 120, VH - 26, 17, 0xFFDDE3FF);
}

void drawHUD() {
  // nyawa (hati)
  for (int i = 0; i < MAX_LIVES; i++) drawHeart(36 + i * 42, 32, 32, i < lives);

  // ikon operasi yang aktif
  int n = 0;
  for (int i = 0; i < 4; i++) {
    if (opOn[i]) {
      drawBadge(i, 28 + n * 32, 78, 12);
      n++;
    }
  }

  // level + bar kemajuan
  label("LEVEL " + level + (level == MAX_LEVEL ? " (MAKS)" : ""), VW / 2.0, 22, 26, 0xFFFFF3B0);
  float bw = 240;
  noStroke();
  fill(0, 0, 0, 110);
  rect(VW / 2.0, 52, bw + 8, 18, 9);
  float prog = constrain(correctInLevel / (float) CORRECT_PER_LEVEL, 0, 1);
  if (level == MAX_LEVEL) prog = 1;
  if (prog > 0) {
    fill(255, 210, 60);
    rect(VW / 2.0 - bw / 2 + bw * prog / 2, 52, bw * prog, 12, 6);
  }

  // skor
  textAlign(RIGHT, CENTER);
  label("Skor: " + score, VW - 24, 28, 28, 0xFFFFE066);
  if (combo >= 2) label("Beruntun x" + combo, VW - 24, 60, 20, 0xFFFF9F1C);
  textAlign(CENTER, CENTER);

  // tombol menu (membuka layar jeda yang berisi pilihan kembali ke menu)
  if (gameState == ST_PLAY) {
    drawButton("MENU", VW - 62, 104, 100, 34, 0xFFE8ECFF, 0xFF3A3F66, 16, false);
  }
}

void drawLevelBanner() {
  float p = 1 - levelBanner / 150.0;
  float a = (levelBanner < 30) ? 255 * levelBanner / 30.0 : 255;
  float s = (p < 0.15) ? easeOutBack(p / 0.15) : 1;
  pushMatrix();
  translate(VW / 2.0, VH / 2.0 - 70);
  scale(s);
  noStroke();
  fill(0, 0, 0, 120 * (a / 255));
  rect(0, 0, 540, 170, 40);
  textSize(76);
  fill(255, 220, 70, a);
  text("LEVEL " + level + "!", 0, -20);
  textSize(24);
  fill(255, 255, 255, a);
  text(bannerBonus ? "Hebat! Kamu dapat +1 nyawa" : "Soal makin seru, semangat!", 0, 45);
  popMatrix();
}

void drawPauseOverlay() {
  noStroke();
  fill(0, 0, 0, 150);
  rect(VW / 2.0, VH / 2.0, VW, VH);
  label("JEDA", VW / 2.0, VH / 2.0 - 70, 80, WHITE);
  drawButton("LANJUT MAIN (P)", VW / 2.0, VH / 2.0 + 20, 320, 56, 0xFF2ED573, WHITE, 24, true);
  drawButton("MENU UTAMA (M)", VW / 2.0, VH / 2.0 + 95, 320, 56, 0xFFFF6B9D, WHITE, 24, true);
}

void goToMenu() {
  currentInput = "";
  gameState = ST_MENU;
}

void goToIntro() {
  introStart = frameCount;
  gameState = ST_INTRO;
}

void drawGameOver() {
  drawBackground();
  noStroke();
  fill(0, 0, 0, 120);
  rect(VW / 2.0, VH / 2.0, 580, 430, 40);
  label("GAME OVER", VW / 2.0, 135, 66, 0xFFFF6B6B);
  label("Jangan menyerah, coba lagi ya!", VW / 2.0, 190, 24, WHITE);

  int stars = (score >= 600) ? 3 : ((score >= 350) ? 2 : ((score >= 150) ? 1 : 0));
  for (int i = 0; i < 3; i++) {
    stroke(255);
    strokeWeight(3);
    if (i < stars) fill(255, 215, 0);
    else fill(90, 90, 130, 180);
    drawStar(VW / 2.0 + (i - 1) * 95, 270, 22, 46, 5);
  }

  label("Skor: " + score, VW / 2.0, 345, 36, 0xFFFFE066);
  label("Level tercapai: " + level + "   |   Skor tertinggi: " + highScore, VW / 2.0, 392, 20, WHITE);
  drawButton("MAIN LAGI (ENTER)", VW / 2.0 - 140, 465, 250, 52, 0xFF2ED573, WHITE, 20, true);
  drawButton("MENU (M)", VW / 2.0 + 140, 465, 220, 52, 0xFFFF6B9D, WHITE, 20, true);
}

// ---------------------------------------------------
// INPUT
// ---------------------------------------------------

void keyPressed() {
  if (key == ESC) {
    key = 0;   // cegah Processing langsung menutup program
    if (gameState == ST_PLAY) gameState = ST_PAUSE;
    else if (gameState == ST_PAUSE) gameState = ST_PLAY;
    else if (gameState == ST_OVER) goToMenu();
    else exit();
    return;
  }

  if (gameState == ST_INTRO) {
    if (key == ENTER || key == RETURN || key == ' ') gameState = ST_MENU;
  } else if (gameState == ST_MENU) {
    if (key >= '1' && key <= '4') toggleOp(key - '1');
    else if (key == 'a' || key == 'A') setAllOps();
    else if (key == 'r' || key == 'R') setRes(resIndex + 1);
    else if (key == 'b' || key == 'B') goToIntro();
    else if (key == ENTER || key == RETURN) startGame();
  } else if (gameState == ST_PLAY) {
    if (key >= '0' && key <= '9') {
      if (currentInput.length() < 3) currentInput += key;
    } else if (key == BACKSPACE && currentInput.length() > 0) {
      currentInput = currentInput.substring(0, currentInput.length() - 1);
    } else if (key == ENTER || key == RETURN) {
      checkAnswer();
    } else if (key == 'p' || key == 'P') {
      gameState = ST_PAUSE;
    }
  } else if (gameState == ST_PAUSE) {
    if (key == 'p' || key == 'P' || key == ENTER || key == RETURN) gameState = ST_PLAY;
    else if (key == 'm' || key == 'M') goToMenu();
  } else if (gameState == ST_OVER) {
    if (key == ENTER || key == RETURN) startGame();
    else if (key == 'm' || key == 'M') gameState = ST_MENU;
  }
}

void mousePressed() {
  if (gameState == ST_INTRO) {
    gameState = ST_MENU;
  } else if (gameState == ST_MENU) {
    if (over(82, 40, 120, 38)) {
      goToIntro();
      return;
    }
    for (int i = 0; i < 4; i++) {
      if (over(cardX(i), CARD_Y, CARD_W, CARD_H)) toggleOp(i);
    }
    if (over(VW / 2.0, ALL_Y, 270, 42)) setAllOps();
    for (int i = 0; i < RES.length; i++) {
      if (over(resX(i), RES_Y, 185, 38)) setRes(i);
    }
    if (over(VW / 2.0, START_Y, 320, 58)) startGame();
  } else if (gameState == ST_OVER) {
    if (over(VW / 2.0 - 140, 465, 250, 52)) startGame();
    if (over(VW / 2.0 + 140, 465, 220, 52)) goToMenu();
  } else if (gameState == ST_PLAY) {
    if (over(VW - 62, 104, 100, 34)) gameState = ST_PAUSE;
  } else if (gameState == ST_PAUSE) {
    if (over(VW / 2.0, VH / 2.0 + 20, 320, 56)) gameState = ST_PLAY;
    if (over(VW / 2.0, VH / 2.0 + 95, 320, 56)) goToMenu();
  }
}

// ---------------------------------------------------
// CLASS ENEMY (monster pembawa soal)
// ---------------------------------------------------

class Enemy {
  float x, y, speed, phase;
  int op, answer, a, b;
  String problemStr;

  Enemy() {
    x = pickX();
    y = -60;
    speed = baseSpeed() * random(0.85, 1.15);
    phase = random(TWO_PI);
    // cari soal yang jawabannya belum dipakai monster lain
    for (int tries = 0; tries < 10; tries++) {
      op = pickOp();
      makeProblem();
      if (!answerUsed(answer)) break;
    }
  }

  void makeProblem() {
    int L = level;
    if (op == 0) {
      int m = 4 + L * 3;
      a = (int) random(1, m + 1);
      b = (int) random(1, m + 1);
      answer = a + b;
      problemStr = a + " + " + b;
    } else if (op == 1) {
      int m = 6 + L * 4;
      a = (int) random(2, m + 1);
      b = (int) random(1, a);          // hasil selalu positif
      answer = a - b;
      problemStr = a + " - " + b;
    } else if (op == 2) {
      int ma = min(10, L + 2);
      int mb = min(10, L + 3);
      a = (int) random(2, ma + 1);
      b = (int) random(2, mb + 1);
      answer = a * b;
      problemStr = a + " x " + b;
    } else {
      int md = min(10, L + 2);
      int mq = min(10, L + 3);
      b = (int) random(2, md + 1);
      answer = (int) random(2, mq + 1);
      a = b * answer;                  // pembagian selalu habis
      problemStr = a + " : " + b;
    }
  }

  void update() {
    y += speed * dt;
  }

  void display() {
    float t = frameCount * 0.07 + phase;
    float dx = sin(t * 0.7) * 6;
    drawMonster(op, x + dx, y, 1.0, t);

    // tanda bahaya saat sudah dekat benteng
    if (y > BASE_TOP - 200 && (frameCount / 10) % 2 == 0) {
      label("!", x + dx, y - 66, 34, 0xFFFF4D4D);
    }

    // papan soal
    textSize(26);
    float w = textWidth(problemStr) + 36;
    float py = y + 66;
    noStroke();
    fill(0, 0, 0, 70);
    rect(x + dx + 2, py + 4, w, 36, 18);
    stroke(OP_COL[op]);
    strokeWeight(4);
    fill(255);
    rect(x + dx, py, w, 36, 18);
    noStroke();
    plain(problemStr, x + dx, py - 2, 26, OP_DARK[op]);
  }
}

// ---------------------------------------------------
// PARTIKEL & TEKS MELAYANG
// ---------------------------------------------------

class Particle {
  float x, y, vx, vy, life, maxLife, size, rot, vr;
  int col;
  boolean star;

  Particle(float x, float y, float vx, float vy, float life, int col, float size, boolean star) {
    this.x = x;
    this.y = y;
    this.vx = vx;
    this.vy = vy;
    this.life = life;
    this.maxLife = life;
    this.col = col;
    this.size = size;
    this.star = star;
    this.rot = random(TWO_PI);
    this.vr = random(-0.2, 0.2);
  }

  void update() {
    x += vx * dt;
    y += vy * dt;
    vy += 0.12 * dt;
    vx *= 0.99;
    rot += vr * dt;
    life -= dt;
  }

  boolean dead() {
    return life <= 0;
  }

  void display() {
    float a = 255 * constrain(life / maxLife, 0, 1);
    noStroke();
    fill(red(col), green(col), blue(col), a);
    if (star) {
      pushMatrix();
      translate(x, y);
      rotate(rot);
      drawStar(0, 0, size * 0.45, size, 5);
      popMatrix();
    } else {
      ellipse(x, y, size, size);
    }
  }
}

class Popup {
  String s;
  float x, y, life;
  int col;

  Popup(String s, float x, float y, int col) {
    this.s = s;
    this.x = constrain(x, 80, VW - 80);
    this.y = y;
    this.col = col;
    this.life = 60;
  }

  void update() {
    y -= 0.8 * dt;
    life -= dt;
  }

  void display() {
    float a = 255 * constrain(life / 25.0, 0, 1);
    textSize(28);
    fill(0, 0, 0, a * 0.4);
    text(s, x + 2, y + 3);
    fill(red(col), green(col), blue(col), a);
    text(s, x, y);
  }
}
